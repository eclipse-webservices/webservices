Currently no arguments to be passed in.  See org.eclipse.jst.ws.tests for adding
arguments when running test suite (i.e. server install location...)
