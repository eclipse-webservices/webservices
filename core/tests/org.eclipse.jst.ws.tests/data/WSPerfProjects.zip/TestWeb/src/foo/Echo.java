package foo;

public class Echo
{
	public String echoString(String input)
	{
		return input;
	}
}